=====================================================
      🎆 PROJETO: SHOW DE FOGOS (HEART EDITION) 🎆
=====================================================

Fala, Tech! Este é um projeto de fogos de artifício em 
formato de corações coloridos, com sintetizador de 
áudio integrado via Web Audio API.

Abaixo, os métodos para você obter o código diretamente 
no seu terminal:

-----------------------------------------------------
OPÇÃO 1: Via Termbin (O mais leve)
-----------------------------------------------------
Comando para baixar:
$ curl https://termbin.com/8n5v > script_v2.js

-----------------------------------------------------
OPÇÃO 2: Via Paste.rs (Visualização rápida)
-----------------------------------------------------
Link para visualizar no navegador:
https://paste.rs/MK2Zj

Comando para baixar:
$ curl https://paste.rs/MK2Zj > script_v2.js

-----------------------------------------------------
OPÇÃO 3: Via Servidor Local (Direto da minha máquina)
-----------------------------------------------------
Se estivermos na mesma rede, baixe direto de mim:
$ curl http://192.168.0.153:8085/script_v2.js > script_v2.js

-----------------------------------------------------
COMO RODAR O PROJETO:
-----------------------------------------------------
1. Certifique-se de ter o arquivo 'index.html' na mesma pasta.
2. O arquivo de script deve se chamar exatamente 'script_v2.js'.
3. Inicie um servidor local para evitar bloqueios de segurança:
   $ python3 -m http.server 8080
4. Abra no navegador: http://localhost:8080
5. CLIQUE NA TELA para ativar o show e o som.

Desenvolvido no [development-torres] por Luis.
=====================================================
